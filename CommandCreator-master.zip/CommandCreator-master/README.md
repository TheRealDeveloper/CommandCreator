# CommandCreator
Create own commands easily without any programming knowledge.
# How to use
1. Download the plugin
2. Put the CommandCreator.phar into your /plugins folder.
3. Start your server
4. Get into the /plugin_data folder and search for CommandCreator.
5. Edit commands.yml and add/remove/edit command how you need them.
6. Restart your server
7. Enjoy your new commands
# Downloads
Latest: [Poggit](https://poggit.pmmp.io/p/CommandCreator)
## All versions:
|Version|Pocketmine|Stable|
|-------|----------|------|
|1.0.0|[Download](https://poggit.pmmp.io/r/62878/CommandCreator_dev-5.phar)|✔|
